# 3d-rails-minecraft-1.12.2

これも小さなMinecraftリソースパックです
レールを3Dにする

This is also a small Minecraft resource pack
Make the rail 3D

このリソースパックは、すべての計算機で機能します
Minecraftのバージョンは1.12以降である必要があります

This resource pack works with all cumputers
Minecraft version must be 1.12 or later

バグを報告したい場合は、不和で私に連絡してください: saubecity#3427

If you want to report a bug please contact me with a discord: saubecity#3427

**warning:** *for some encoding reason, you must unzip the resource pack beford using it*

**警告：** *エンコード上の理由により、リソースパックを使用する前に解凍する必要があります*
